/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array_miglio;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author verifica25
 */
public class Array_Miglio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Variabili
        int n = (int) (Math.random()*7 + 12); //numerosità caselle array principale
        int k = (int) (Math.random()*2 + 3); //quanti thread
        int[] arr = null; //array statico
        int start = 0;
        int end = 0;
        //for per gli interi random 
        for(int i = 0; i < n; i++){
            arr[i] = (int) (Math.random()* 100); 
            
        }
        
        //divisione celle per Thread
        int div = (int) (n/k); //divisione caselle per ogni thread
        Worker[] threads = new Worker[k];
        for(int i=0; i<k; i++){
            start = i* div;
            end = (i + div) - 1;
           threads[i] = new Worker(arr, start, end);
           //threads[i].start();
           
        }
        int conta =0;
        while(conta < k){
            //threads[conta].join();
            conta++;
        }
    }
    
}
