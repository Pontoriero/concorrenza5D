/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array_miglio;

/**
 *
 * @author verifica25
 */
public class Worker implements Runnable{
    private int[] arr;
    private int start;
    private int end;

    public Worker(int[] arr, int start, int end) {
        this.arr = arr;
        this.start = start;
        this.end = end;
    }

    @Override
    public void run() {
        for(int i = start; i<end; i++){
            int dec = arr[i]/10;
            int un = arr[i]%10;
            int val = (dec + un ) * i;
        }
    }
    
    
}
