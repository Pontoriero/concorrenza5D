/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package porto_miglio;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author verifica25
 */
public class Porto_Miglio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       CapitaneriaDiPorto c = new CapitaneriaDiPorto();
       Thread n = null;
       for( int i = 1; i <= 10; i++){
            n = new Thread ( new Nave(i,c));
            n.start();
        }
    }
}