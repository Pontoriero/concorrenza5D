/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package porto_miglio;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author verifica25
 */
public class Nave implements Runnable{
    private int id;
    CapitaneriaDiPorto c;

    public Nave(int id, CapitaneriaDiPorto c) {
        this.id = id;
        this.c = c;
    }
    
    
    @Override
    public void run() {
        
            try {
                if(id >= 1 || id <= 5){
                    Thread.sleep((long) (Math.random()* 10 + 10));
                    c.entrataNazionale();
                    Thread.sleep((long) (Math.random()* 10 + 10));
                    c.uscitaNazionale();
                }else{
                    Thread.sleep((long) (Math.random()* 10 + 10));
                    c.entrataInternazionale();
                    Thread.sleep((long) (Math.random()* 10 + 10));
                    c.uscitaInternazionale();
                }
            } catch (InterruptedException ex) {
                Logger.getLogger(Nave.class.getName()).log(Level.SEVERE, null, ex);
            }
        
    }
    
}
