/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package porto_miglio;

/**
 *
 * @author verifica25
 */
public class CapitaneriaDiPorto extends Thread{
    
    private int contaNazionale;
    private int contaInternazionale;
    private int contaAttesaNaz;
    private int contaAttesaInternaz;
    
    

    public CapitaneriaDiPorto() {
        this.contaNazionale = 0;
        this.contaInternazionale = 0;
        this.contaAttesaNaz = 0;
        this.contaAttesaInternaz = 0;
        
    }
    
    public synchronized void uscitaNazionale(){
        contaAttesaNaz --;
        System.out.println("è uscito dalla banchina");
        
        notifyAll();
    }
    
    public synchronized void uscitaInternazionale(){
        contaAttesaInternaz --;
        System.out.println("è uscito dalla banchina");
        
        notifyAll();
    }
    
    public synchronized void entrataNazionale() throws InterruptedException{
        contaAttesaNaz ++;
        if(contaNazionale == 3 || contaInternazionale > 0){
            wait();
            System.out.println("è in attesa...");
        }
        contaAttesaNaz --;
        contaNazionale ++;
        System.out.println("è entrato nella banchina");
    }
    
    public synchronized void entrataInternazionale() throws InterruptedException{
        contaAttesaInternaz ++;
        if(contaInternazionale == 3 || contaNazionale > 0 || contaAttesaNaz > 0){
            wait();
            System.out.println("è in attesa..." );
        }
        contaAttesaInternaz --;
        contaInternazionale ++;
        System.out.println("è entrato nella banchina");
    }
}
